package VisitPlann.DTOS;

public class UserDto {
        private String username;
        public String token;
        private String knowAs;
        private String gender;
    }




