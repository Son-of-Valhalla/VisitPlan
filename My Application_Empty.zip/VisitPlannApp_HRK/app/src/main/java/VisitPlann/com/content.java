package VisitPlann.com;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class content extends AppCompatActivity {
    final String URL= "https://visitplann.herokuapp.com/api/Utilitis/content/";
    private String category="a1";
    private String URLcat="";
    private String htmlstring ="";
    private WebView webView;
    SharedPreferences prefs;







    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_view);
        webView=findViewById(R.id.webView3);
        webView.getSettings().setSupportZoom(true);
        category=getCategory();
        URLcat= URL + category;
        Log.d("URL", URLcat);

        Button btn=findViewById(R.id.button4);
        btn.performClick();




    }


    public void Gethtml (View view) {

        JsonObjectRequest req = new JsonObjectRequest(Request.Method.GET, URLcat, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("html", response.toString());

                        try {
                            htmlstring = response.getJSONObject("item1").getString("content");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        Log.d("html2", htmlstring);


                        webView.loadData(htmlstring,
                                "text/html", "UTF-8");                        }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }

                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                return headers;
            }
        };



        //try not show timeout error
        //  JsonRequest.setRetryPolicy(new DefaultRetryPolicy(20 * 1000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(req);

    }
    private String getCategory() {
        prefs=content.this.getSharedPreferences("Category",Context.MODE_PRIVATE);
        String Category = prefs.getString("Category","");
        return Category;
    }
    public void Mainapp(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}