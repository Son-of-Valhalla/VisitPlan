package VisitPlann.com;

public interface VisionListener {
    void onImageFound(String VisionCla);

}
