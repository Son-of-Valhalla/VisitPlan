package VisitPlann.com;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.util.Size;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.LifecycleOwner;

import com.google.common.util.concurrent.ListenableFuture;

import org.json.JSONException;

import java.util.concurrent.ExecutionException;


public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_CAMERA = 0;
    private PreviewView previewView;
    private ListenableFuture<ProcessCameraProvider> cameraProviderFuture;
    private WebView webView;
    private String contentCat;
    SharedPreferences prefs;
    SharedPreferences.Editor edit;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        previewView = findViewById(R.id.activity_main_previewView);
        cameraProviderFuture = ProcessCameraProvider.getInstance(this);
        requestCamera();

        webView = (WebView) findViewById(R.id.webView2);
        webView.getSettings().setSupportZoom(true);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // do your handling codes here, which url is the requested url
                // probably you need to open that url rather than redirect:
                view.loadUrl(url);
                return false; // then it is not handled by default action
            }
        });
        webView.setVisibility(View.GONE);

        Button btn=findViewById(R.id.button8);
        btn.setVisibility(View.INVISIBLE);





    }

    private void requestCamera() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.CAMERA}, PERMISSION_REQUEST_CAMERA);
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, PERMISSION_REQUEST_CAMERA);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CAMERA) {
            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startCamera();
            } else {
                Toast.makeText(this, "Camera Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void startCamera() {
        cameraProviderFuture.addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = cameraProviderFuture.get();
                bindCameraPreview(cameraProvider);
            } catch (ExecutionException | InterruptedException e) {
                Toast.makeText(this, "Error starting camera " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    /**
     * The bindCameraPreview(…) method will be used to set up and
     * initiate the camera preview to be displayed inside the PreviewView widget.
     **/
    private void bindCameraPreview(@NonNull ProcessCameraProvider cameraProvider) {
        /**
         * set up the PreviewView widget to use the surface view implementation mode using the
         * setPreferredImplementationMode(…) method.
         * **/
        previewView.setPreferredImplementationMode(PreviewView.ImplementationMode.SURFACE_VIEW);

        Preview preview = new Preview.Builder()
                .build();

        /**
         * CameraSelector object using the builder using the back lens of the camera.
         * **/
        CameraSelector cameraSelector = new CameraSelector.Builder()
                .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                .build();

        preview.setSurfaceProvider(previewView.createSurfaceProvider());
        ImageAnalysis imageAnalysis =
                new ImageAnalysis.Builder()
                        .setTargetResolution(new Size(1280, 720))
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build();

        imageAnalysis.setAnalyzer(ContextCompat.getMainExecutor(this), new VisionImageAnalyzer(this, new VisionListener() {
            @Override
            public void onImageFound(String VisionClassificacao) {
                webView.setVisibility(View.VISIBLE);
                webView.setBackgroundColor(Color.TRANSPARENT);
                /**--Enviar VisionClassificação --- Consoante o Score dar Feedback ---**/
                webView.loadDataWithBaseURL(null, "<html><body><pre>" + VisionClassificacao + "</pre></body></html>", "text/html", "UTF-8", null);
                Log.i("DETECTION", VisionClassificacao);

                Button btn=findViewById(R.id.button8);

                contentCat=VisionClassificacao;




              if (contentCat!=""){
                  btn.setText("Ver "+ contentCat);
                  btn.setVisibility(View.VISIBLE);
                prefs=MainActivity.this.getSharedPreferences("Category", Context.MODE_PRIVATE);
                edit=prefs.edit();
                edit.putString("Category",contentCat);
                Log.i("Category",contentCat);
                edit.commit();


            }
        }


        }));

        Camera camera = cameraProvider.bindToLifecycle((LifecycleOwner) this, cameraSelector, imageAnalysis, preview);
    }
    /**
     * Image analysis capabilities available in CameraX along with the
     * ZXing library to scan image frames from the camera to locate QR codes.
     **/
    public void Content(View view) {
        Intent intent = new Intent(this, content.class);
        startActivity(intent);
        finish();
    }

}